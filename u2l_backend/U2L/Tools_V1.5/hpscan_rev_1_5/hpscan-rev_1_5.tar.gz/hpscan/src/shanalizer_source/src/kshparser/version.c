/*
 * value of $KSH_VERSION (or $SH_VERSION)
 */

#include "sh.h"

const char ksh_version [] =
	"@(#)PD KSH v5.2.14 99/07/13.2";
