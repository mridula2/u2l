#!/bin/sh
# $Header: /data/cvsrepo/hpscan/src/shanalizer_source/src/kshparser/kshparser.sh,v 1.1 2015/09/08 09:23:40 kozeni Exp $
# BASE source : /data/cvsrepo/hpscan/shanalyze/kshparser.sh,v 1.11 2014/02/13 07:51:39 morimoto
# (C) 2008 Hewlett-Packard Development Company, L.P.

########################################################
## DON'T CHANGE/MODIFY THIS SOURCE CODE.
## Change hpsacan/shanalyze/kshparser.sh, please !
########################################################

#######################################################################
# History
# * 2009/01/09 
#  add func_parsebackquoteksh() and func_parsecasearc()
#  in order to handle 
#     1) more than two backquotes or casearc
#          example) backquotes : `cmd`,  casearc : $(cmd)
#     2) backquotes and casearc at not xx=`xxx` style 
##########################################################################

PARSER="kshparser"

######################################################################
# func_parsebackquoteksh() is effective upto five pairs of backquotes.
######################################################################
function func_parsebackquoteksh {
export FNAME=$1
# delete comment line
sed 's/^[ 	]*#.*$//' $FNAME |
# pickup ` line and add line number
grep -n \` |
# remove line : <line_num>:  ABC_VAL=`....
grep -v "^[0-9]*:[ 	]*[_a-zA-Z0-9]*=\`" |
# extract `` contents ( `abc` ==> abc )
sed -n \
-e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4\
\1 \5\
\1 \6/p' \
-e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4\
\1 \5/p' \
-e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4/p' \
-e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3/p' \
-e 's/^\([0-9]*\):.*`\(.*\)`.*/\1 \2/p' > $TMPFILE

	func_print_othercmd $TMPFILE
	rm -f $TMPFILE
}

######################################################################
# func_parsecasearc() is effective upto five pairs of casearcs.
######################################################################
function func_parsecasearc {
export FNAME=$1
# delete comment line and remove '' content
sed -e 's/^[ 	]*#.*$//' \
-e "s/\'.*\'/\'\'/g" $FNAME |
# pickup ( line and add line number
grep -n \$\( |
# remove line : <line_num>:  ABC_VAL=$...
grep -v '^[0-9]*:[ 	]*[_a-zA-Z0-9]*=\$' |
sed -n \
-e 's/^\(.*\):.*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*$/\1 \2\
\1 \3\
\1 \4\
\1 \5\
\1 \6/p' \
-e 's/^\(.*\):.*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*$/\1 \2\
\1 \3\
\1 \4\
\1 \5/p' \
-e 's/^\(.*\):.*\$(\(.*\)).*\$(\(.*\)).*\$(\(.*\)).*$/\1 \2\
\1 \3\
\1 \4/p' \
-e 's/^\(.*\):.*\$(\(.*\)).*\$(\(.*\)).*$/\1 \2\
\1 \3/p' \
-e 's/^\(.*\):.*\$(\(.*\)).*$/\1 \2/p' > $TMPFILE

	func_print_othercmd $TMPFILE
	rm -f $TMPFILE

}

#
# parse command pipe stream
#
#  ex)
#    input  : cmd |cmd2 |cmd3
#    output : C cmd fname line#
#             C cmd2 fname line#
#             C cmd3 fname line#
#
function func_print_othercmd {
awk '{
    linenum=$1;
    line=$0;
    flag=0;
    gsub("^[0-9]* ","",line);
    num=split(line, ary, "|");
    for (i=0; i<num; i++) {
        tgt=ary[i+1];
        gsub("^[    ]", "", tgt);
        split(tgt, ary2, " ");
        if ( flag == 0 ) {
            cmd=ary2[1];
            printf("C %s %s %s\n", cmd,ENVIRON["FNAME"],linenum)
        }
        if ( tgt ~ /.*\"|\047.*/ ) {
            tmp=tgt
            gsub(/\\\"/,"  ",tmp);
            gsub(/\\\047/,"  ",tmp);
            if ( (gsub("\"|\047"," ",tmp) % 2) == 1 ) {
                flag=!flag;
            }
        }
    }
}' $1
}

TMPFILE=/var/tmp/back.$$
trap 'rm -f $TMPFILE;exit 1' 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

for x in $*
do
	$PARSER $x | grep -v "^C typeset " | grep -v 'C \[ ' | sed 's/"//g'
	func_parsebackquoteksh $x
	func_parsecasearc $x
done

