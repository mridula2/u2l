dfdfdfsfsd
dsfsdfsdfsd
sdfsdfsdfsdf
sdfsdfsdfs
if [ -eq 1]; then
echo "danny"
fi
dfsdfd
sdfsdfsdf
sdfsdffddddddddddddddddddddd
sdfsdfsdfsdfsdfsdf
sdfsdfsdfsdf
sdfsdfsdf
sdfsdfsdf
sdfsdfsd
sdfsdfsd
sdfsdf
sdfsdfsd
sdfsdfs
sdfsdf
sdfsd
sffsd
if [ -f /home/danny ]; then
	echo "hai guys"
fi

dfsdfsd
sfsdfsdfsd
			sdasdasdasda
					asdasdada
