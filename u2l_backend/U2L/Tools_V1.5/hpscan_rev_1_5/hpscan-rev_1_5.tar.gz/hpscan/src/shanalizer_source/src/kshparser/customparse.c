#include <stdio.h>
// States

#define			ST_START						0
#define			ST_COMMAND						1
#define			ST_COMMAND_SQ					2
#define			ST_COMMAND_DQ					3
#define			ST_ARGS							4
#define			ST_ARGS_SQ						5
#define			ST_ARGS_DQ						6
#define			ST_PIPE							7
#define			ST_AMPERSAND					8

#define			STATE_COUNT						9

// Character mappings

#define			CHR_DEFAULT						0
#define			CHR_NULL						1
#define			CHR_SPACE						2
#define			CHR_TAB							3
#define			CHR_SQ							4
#define			CHR_DQ							5
#define			CHR_PIPE						6
#define			CHR_AMPERSAND					7
#define			CHR_BACK_SLASH					8

#define			CHR_COUNT						9

// Actions

#define			ACT_IGNORE						0
#define			ACT_PRINT						1
#define			ACT_ADD_TO_COMMAND				2
#define			ACT_ADD_NEXT_CHAR_TO_COMMAND	3
#define			ACT_IGNORE_NEXT_CHAR			4

struct action
{
	int action;
	int newState;
};

struct action stateMachine[STATE_COUNT][CHR_COUNT] = 
				{
				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND},			//START, DEFAULT
					{ACT_IGNORE, ST_START}, 					//START, NULL
					{ACT_IGNORE, ST_START}, 					//START, SPACE
					{ACT_IGNORE, ST_START},						//START, TAB
					{ACT_IGNORE, ST_COMMAND_SQ}, 				//START, SQ
					{ACT_IGNORE, ST_COMMAND_DQ}, 				//START, DQ
					{ACT_IGNORE, ST_START}, 					//START, PIPE
					{ACT_IGNORE, ST_START}, 					//START, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND}	//START, BACKSL
				  },

				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND},			//CMD, DEFAULT
					{ACT_PRINT, ST_ARGS},	 					//CMD, NULL
					{ACT_PRINT, ST_ARGS}, 						//CMD, SPACE
					{ACT_PRINT, ST_ARGS},						//CMD, TAB
					{ACT_IGNORE, ST_COMMAND_SQ}, 				//CMD, SQ
					{ACT_IGNORE, ST_COMMAND_DQ}, 				//CMD, DQ
					{ACT_PRINT, ST_PIPE}, 						//CMD, PIPE
					{ACT_IGNORE, ST_AMPERSAND},					//CMD, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND}	//CMD, BACKSL
				  },

				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ},		//CMDSQ, DEFAULT
					{ACT_PRINT, ST_ARGS},	 					//CMDSQ, NULL
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ}, 		//CMDSQ, SPACE
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ},		//CMDSQ, TAB
					{ACT_IGNORE, ST_COMMAND}, 					//CMDSQ, SQ
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ}, 		//CMDSQ, DQ
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ}, 		//CMDSQ, PIPE
					{ACT_ADD_TO_COMMAND, ST_COMMAND_SQ}, 		//CMDSQ, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND_SQ}
																//CMDSQ, BACKSL
				  },

				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ},		//CMDDQ, DEFAULT
					{ACT_PRINT, ST_ARGS},	 					//CMDDQ, NULL
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ}, 		//CMDDQ, SPACE
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ},		//CMDDQ, TAB
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ},		//CMDDQ, SQ
					{ACT_IGNORE, ST_COMMAND}, 					//CMDDQ, DQ
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ}, 		//CMDDQ, PIPE
					{ACT_ADD_TO_COMMAND, ST_COMMAND_DQ}, 		//CMDDQ, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND_DQ}
																//CMDDQ, BACKSL
				  },

				  {
					{ACT_IGNORE, ST_ARGS},						//ARGS, DEFAULT
					{ACT_IGNORE, ST_ARGS},	 					//ARGS, NULL
					{ACT_IGNORE, ST_ARGS}, 						//ARGS, SPACE
					{ACT_IGNORE, ST_ARGS},						//ARGS, TAB
					{ACT_IGNORE, ST_ARGS_SQ}, 					//ARGS, SQ
					{ACT_IGNORE, ST_ARGS_DQ}, 					//ARGS, DQ
					{ACT_IGNORE, ST_PIPE}, 						//ARGS, PIPE
					{ACT_IGNORE, ST_AMPERSAND},					//ARGS, AMPER
					{ACT_IGNORE_NEXT_CHAR, ST_ARGS}				//ARGS, BACKSL
				  },

				  {
					{ACT_IGNORE, ST_ARGS_SQ},					//ARGSSQ, DEFAUT
					{ACT_IGNORE, ST_ARGS_SQ}, 					//ARGSSQ, NULL
					{ACT_IGNORE, ST_ARGS_SQ},					//ARGSSQ, SPACE
					{ACT_IGNORE, ST_ARGS_SQ},					//ARGSSQ, TAB
					{ACT_IGNORE, ST_ARGS}, 						//ARGSSQ, SQ
					{ACT_IGNORE, ST_ARGS_SQ}, 					//ARGSSQ, DQ
					{ACT_IGNORE, ST_ARGS_SQ},					//ARGSSQ, PIPE
					{ACT_IGNORE, ST_ARGS_SQ},					//ARGSSQ, AMPER
					{ACT_IGNORE_NEXT_CHAR, ST_ARGS_SQ}			//ARGSSQ, BACKSL
				  },

				  {
					{ACT_IGNORE, ST_ARGS_DQ},					//ARGSDQ, DEFAUT
					{ACT_IGNORE, ST_ARGS_DQ}, 					//ARGSDQ, NULL
					{ACT_IGNORE, ST_ARGS_DQ},					//ARGSDQ, SPACE
					{ACT_IGNORE, ST_ARGS_DQ},					//ARGSDQ, TAB
					{ACT_IGNORE, ST_ARGS_DQ}, 					//ARGSDQ, SQ
					{ACT_IGNORE, ST_ARGS}, 						//ARGSDQ, DQ
					{ACT_IGNORE, ST_ARGS_DQ},					//ARGSDQ, PIPE
					{ACT_IGNORE, ST_ARGS_DQ},					//ARGSDQ, AMPER
					{ACT_IGNORE_NEXT_CHAR, ST_ARGS_DQ}			//ARGSDQ, BACKSL
				  },

				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND},			//PIPE, DEFAUT
					{ACT_IGNORE, ST_PIPE}, 						//PIPE, NULL
					{ACT_IGNORE, ST_START},						//PIPE, SPACE
					{ACT_IGNORE, ST_START},						//PIPE, TAB
					{ACT_IGNORE, ST_COMMAND_SQ},				//PIPE, SQ
					{ACT_IGNORE, ST_COMMAND_DQ}, 				//PIPE, DQ
					{ACT_IGNORE, ST_START},						//PIPE, PIPE
					{ACT_IGNORE, ST_START},						//PIPE, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND}	//PIPE, BACKSL
				  },

				  {
					{ACT_ADD_TO_COMMAND, ST_COMMAND},			//AMPR, DEFAUT
					{ACT_IGNORE, ST_AMPERSAND}, 				//AMPR, NULL
					{ACT_IGNORE, ST_START},						//AMPR, SPACE
					{ACT_IGNORE, ST_START},						//AMPR, TAB
					{ACT_IGNORE, ST_COMMAND_SQ},				//AMPR, SQ
					{ACT_IGNORE, ST_COMMAND_DQ}, 				//AMPR, DQ
					{ACT_IGNORE, ST_START},						//AMPR, PIPE
					{ACT_IGNORE, ST_START},						//AMPR, AMPER
					{ACT_ADD_NEXT_CHAR_TO_COMMAND, ST_COMMAND}	//AMPR, BACKSL
				  }
				};

static int mapChar (char ch)
{
	switch (ch) {

		case '\0':
			return CHR_NULL;

		case ' ':
			return CHR_SPACE;

		case '\t':
			return CHR_TAB;

		case '\'':
			return CHR_SQ;

		case '"':
			return CHR_DQ;

		case '|':
			return CHR_PIPE;

		case '&':
			return CHR_AMPERSAND;

		case '\\':
			return CHR_BACK_SLASH;

		default:
			return CHR_DEFAULT;
	}
}

static char *gptr;

static char *fileName;
static int lineNo;

static void action (char ch)
{
	struct action act;

	static int state = ST_START;
	static char command [1024];
	static char *ptr = command;

	act = stateMachine[state][mapChar (ch)];

	switch (act.action) {

		case ACT_PRINT:

			*ptr = 0;
			printf ("C %s %s %d\n", command, fileName, lineNo);
			ptr = command;
			break;

		case ACT_ADD_TO_COMMAND:

			*ptr++ = ch;
			break;

		case ACT_ADD_NEXT_CHAR_TO_COMMAND:

			*ptr++ = *++gptr;
			break;

		case ACT_IGNORE_NEXT_CHAR:

			gptr++;
			break;

		case ACT_IGNORE:
		default:
			break;
	}

	state = act.newState;

	//printf ("%c,%d\n", ch, state);
}

void customparse (char *line, char *fn, int ln)
{
	gptr = line;
	fileName = fn;
	lineNo = ln;

	while (1) {

		action (*gptr);

		if (*gptr == 0)
			break;

		gptr++;
	}
}

/*
main ()
{
	int len;
	char buf[1024];
	int i;

	gets (buf);

	gptr = buf;

	while (1) {

		action (*gptr);

		if (*gptr == 0)
			break;

		gptr++;
	}
}
*/
