outfile=./kshparser.out

for f in `ls ../tcase/in.* |grep -v '~'`
do
	echo "===== CASE : $f"
	for d in ../kshparser ../kshparser-no-printop-func ../kshparser-print-backquote-CMD ../pdksh-print ../pdksh-print-2
	do
		if [ -d "$d" ]
		then
		echo "----- DIR : $d"
		top=`pwd`;
		(
			cd $d
			if [ -s "$outfile" ]; then rm $outfile; fi
			./ksh $f
			if [ -s "$outfile" ]; then cat $outfile; fi
		)
		cd $top;	
		else
			echo "[ERROR] can NOT find $d directory (pwd:`pwd`)"
		fi
	done
done
