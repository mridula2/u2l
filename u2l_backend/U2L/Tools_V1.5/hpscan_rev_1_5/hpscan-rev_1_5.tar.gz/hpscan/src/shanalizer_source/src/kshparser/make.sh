
./configure

if [ ! -f Makefile ]; then
	echo "ERROR: don't exists Makefile, check ./configure results..."
	exit 1;
fi

case "`uname -s`" in
Linux | HP-UX )
	cat Makefile |sed 's/^LIBS =.*$/LIBS =/' >Makefile.tmp
	if [ -f Makefile.tmp ]; then
		mv Makefile.tmp Makefile
		echo "INFO: Makefile updated. (LIBS =)"
	fi
	;;
esac

make

