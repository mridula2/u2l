
はじめに

make方法
  $ ./make.sh

　詳細は、READMEファイルを参照下さい。

実行ファイル
　上記にてmakeするとkshという実行ファイルが作成されるので
　ksh を kshparserという名前に変更して下さい。

  $ mv ksh kshparser

注意事項：
　チェックアウトしたディレクトリを他のサーバにコピーして
　makeを実行する場合、以下のようにファイルの時間もコピーして
　makeしないとmakeに失敗します。

　$ cp -rp hpscan workdir/
　$ scp -rp hpscan server1:work

  NG : $ cp -r hpscan workdir/

