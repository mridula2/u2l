/* $Header: /data/cvsrepo/hpscan/src/shanalizer_source/src/cshparser/patchlevel.h,v 1.1 2013/06/24 10:49:49 miya Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 15
#define PATCHLEVEL 0
#define DATE "2007-03-03"

#endif /* _h_patchlevel */
