f=$1
outfile=./kshparser.out

echo "----- CASE : $f"
if [ -s "$outfile" ]; then rm $outfile; fi
./ksh $f
if [ -s "$outfile" ]; then cat $outfile; fi

