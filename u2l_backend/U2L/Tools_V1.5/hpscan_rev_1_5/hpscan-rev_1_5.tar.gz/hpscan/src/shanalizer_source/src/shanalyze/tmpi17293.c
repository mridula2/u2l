#include "sh.h"
	{ QwErTy SIGNALS , "DUMMY" , "hook for number of signals" },
Executing:/usr/bin/sed
