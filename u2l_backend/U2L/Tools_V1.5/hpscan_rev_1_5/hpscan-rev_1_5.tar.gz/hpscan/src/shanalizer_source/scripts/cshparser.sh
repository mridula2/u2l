#!/usr/bin/sh
# $Header: /data/cvsrepo/hpscan/src/shanalizer_source/scripts/cshparser.sh,v 1.1 2008/03/25 11:58:55 cho Exp $
# This i a wrapper for 'cshparser'.
# It adds some more functions to cshparser.
#   1) handle here document
#   2) handle back quotation
#   3) handle multiple lines separated by back slash.


function func_cutheredoc {
  # at first, elemenate string quotation in order not to handle ''<<'
  # within string quotation as here document.
  # It cannot handle non-ASCII text
sed -e 's/^[ 	]*#.*$//' \
-e "s/\'[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\. 	]*\'/\'\'/g" \
-e 's/"[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\.{}() 	]*"/""/g' |
awk '{
    if (match($0,"<<")) {
        split($0, to, /<</);
        left=to[2];
        gsub("^[    ]*","",left);
        split(left, key);
        tgt=key[1];
        print to[1];
        getline;
        while (!match($0, tgt)) {
            print "";
            getline;
        }
        print "";
    } else {
        print;
    }
}'
}
function func_holdbackslash {
awk '
/\\$/ {
    line=$0;
    gsub("\\\\$", "", line);
    endback++;
    printf("%s", line);
    continue;
}
{
    print $0;
    if ( endback > 0 ) {
        for ( i=0; i < endback ; i++ ) {
            print "#"
        }
        endback=0;
    }
}' $1
}

function func_parsebackquote {
	export FNAME="$1"
    #grep -v '^[    ]*#.*' | grep -n \` $x |\
    sed 's/^[ 	]*#.*$//' $FNAME | grep -n \` |\
    sed -n 's/^\(.*\):\(.*\)`\(.*\)`\(.*\)$/\1 \3/gp' > $TMPFILE
    wc=`cat $TMPFILE|wc -l`
    if [ $wc -ne 0 ] ; then
        #/usr/bin/env FNAME="$x" | awk '{printf("C %s %s %s\n", $2,ENVIRON["FNAME"],$1)}' $TMPFILE
awk '{
	linenum=$1;
	line=$0;
	gsub("^[0-9]* ","",line);
	num=split(line, ary, "|");
	for (i=0; i<num; i++) {
		tgt=ary[i+1];
		gsub("^[ 	]", "", tgt);
		split(tgt, ary2, " ");
		cmd=ary2[1];
		printf("C %s %s %s\n", cmd,ENVIRON["FNAME"],linenum)
	}
}' $TMPFILE
    fi
	rm -f $TMPFILE
}


TMPFILE=/var/tmp/back.$$
trap 'rm -f $TMPFILE;exit 1' 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

if [ -z "$HPSCAN" ] ; then
    SH_TOP=${SH_TOP:-/usr/local/hpscan/scripts}
else
    SH_TOP=$HPSCAN/scripts
fi

unset HOME
PATH=$PATH:.

for x in $*
do
#	cat $x | func_cutheredoc
	func_holdbackslash $x |func_cutheredoc| $SH_TOP/cshparser |
	/usr/bin/env FNAME="$x" \
	awk '{printf("%s %s %s %s\n",$1,$2,ENVIRON["FNAME"],$3)}'
	func_parsebackquote $x
done
