Executing:/usr/bin/cc
