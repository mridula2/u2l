d=$1
outfile=./kshparser.out

if [ -d "$d" ]
then
	echo "===== TEST DIR : $d"
else
	echo "[ERROR] can NOT find $d directory (pwd:`pwd`)"
fi

cd $d

for f in `ls ../tcase/in.* |grep -v '~'`
do
	echo "----- CASE : $f"
	if [ -s "$outfile" ]; then rm $outfile; fi
	./ksh $f
	if [ -s "$outfile" ]; then cat $outfile; fi
done

