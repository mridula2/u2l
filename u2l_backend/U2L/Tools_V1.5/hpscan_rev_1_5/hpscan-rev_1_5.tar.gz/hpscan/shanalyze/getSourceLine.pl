#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/shanalyze/getSourceLine.pl,v 1.3 2016/08/26 09:22:58 meguro Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script get file context from list_file. Do this script in source root directory.
# parameter : list_file : filename <tb> linenum
# output    : filename <tb> linenum <tb> context

use File::Basename;

sub usage {
	print "Usage : " . basename($0) . " list_file\n";
	print "list_file : filename<tab>linenum\n";
	exit 1;
}

if ( @ARGV != 1) {
	usage;
}

my $inputFile = $ARGV[0];

if (! -r $inputFile) {
	print "file not found.($inputFile)\n";
	usage;
}

open($fh,"<", $inputFile) or die  "Can't open $filename: $!";
while (my $line = <$fh>) {
	chomp($line);
	@vars = split(/\t/, $line);

	print $line . "\t";
	my $sourceline;
	my $find = 0;
	open($sfh, "<", $vars[0]) or die "Can't open $vars[0]";
	while (<$sfh>) {
		if ( $. == $vars[1]) {
			chomp;
			$sourceline = $_;
			$sourceline =~ s/^\s+//;
			$sourceline =~ s/\s+$//;
			$sourceline =~ s/\s+/ /g;
			print $sourceline."\n";
			$find = 1;
			last;
		}
	}
	if ($find == 0) {
		print "\n";
	}
	close($sfh);
}
close($hf);

