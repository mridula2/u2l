#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/findspecical.sh,v 1.4 2014/01/30 06:34:52 morimoto Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.

for x in $*
do
	sed -e 's/^[ 	]*#.*$//' $x | grep -n -e '`.*`.*`' -e '{.*{.*{' -e \$\(
	if [ $? -eq 0 ] ; then
		echo "#XXX $x"
	fi
done
