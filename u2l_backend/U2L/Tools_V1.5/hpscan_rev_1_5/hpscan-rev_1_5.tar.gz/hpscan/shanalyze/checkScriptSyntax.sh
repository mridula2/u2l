#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/checkScriptSyntax.sh,v 1.3 2016/08/26 08:41:09 meguro Exp $
# (C) 2013 Hewlett-Packard Development Company, L.P.

DEFAULT_SHEBANG=${DEFAULT_SHEBANG:=/bin/sh}

usage () {
	echo "usage:`basename $0` script_file_list"
	exit 1
}

if [ $# -ne 1 ] ; then
	usage
fi

FILE_LIST=$1
if [ ! -r ${FILE_LIST} ] ; then
	echo "file:${FILE_LIST} cannot read."
	exit 1
fi

total_count=0
ok_count=0
ng_count=0
for file in `cat ${FILE_LIST}`
do
	total_count=`expr ${total_count} + 1`
	if [ ! -e ${file} ] ; then
		ng_count=`expr ${ng_count} + 1`
		echo "FILE_NOT_FOUND	${file}"
		continue
	fi
	shebang=`cat ${file} | head -1 | grep "^\#\!" | sed 's/^\#\![ ]*//' | cut -d' ' -f1`
	if [ -z "${shebang}" ] ; then
		shebang=${DEFAULT_SHEBANG}
	fi

	if [ ! -e ${shebang} ] ; then
		ng_count=`expr ${ng_count} + 1`
		echo "SHEBANG_ERR	${file}	${shebang}"
		continue
	fi

	check_result=`LANG=C ${shebang} -n ${file} 2>&1`
	returnCode=$?
	if [ ${returnCode} -eq 0 ] ; then
		ok_count=`expr ${ok_count} + 1`
	else 
		ng_count=`expr ${ng_count} + 1`
		echo "${file}	${check_result}" | sed -e "s/^/SYNTAX_ERR	/g"
	fi
done

echo ""
echo "CHECK SUMMARY"
echo "TOTAL :${total_count}"
echo "OK    :${ok_count}"
echo "NG    :${ng_count}"

