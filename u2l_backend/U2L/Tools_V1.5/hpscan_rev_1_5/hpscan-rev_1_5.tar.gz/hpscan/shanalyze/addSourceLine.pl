#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/shanalyze/addSourceLine.pl,v 1.1 2014/12/25 07:55:28 meguro Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script add the original source line to each line-end of the parser_out_file.
# input     : stdin                : ex.) C CMD rm ./foo.sh 99
# output    : stdout               : ex.) C CMD rm ./foo.sh 99 rm -f $bar

while(<>) {

	chomp;
	my $fullline = $_;
	my @line = split(/\t/, $fullline);
	my $filename = $line[4];
	my $linenum = $line[5];

#	if ($line[3] eq '') {
#		$line[3] = "(null)";
#		$fullline = $line[0];
#		for (my $i = 1; $i <= 5; $i++) {
#			$fullline .= "\t" . $line[$i];
#		}
#	}

	my $fh;
	if (!open($fh, "$filename" )) {
#		print STDERR "$fullline\n"; 
		print "$fullline\n"; 
		next;
	}
	my $sourceline;
	while(<$fh>) {
		if ($. == $linenum) {
		    chomp;
			$sourceline = $_;
			$sourceline =~ s/^\s+//;
			$sourceline =~ s/\s+$//;
			$sourceline =~ s/\s+/ /g;
			last;
		}
	}
	close($fh);

	printf("%s\t%s\n", $fullline, $sourceline);

}

