#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/anaana.sh,v 1.1 2013/09/04 06:39:17 sodo Exp $
# (C) 2009 Hewlett-Packard Development Company, L.P.
# Extract lines from analized file (output of check-parsed.sh ).

export CMD="$2"

awk '{
        if ( ( $1 == "++" && $2 == ENVIRON["CMD"] ) ||
                 ( $1 == "--" && $2 == ENVIRON["CMD"] ) ) {
                getline;
                print $0;
        }
}' $1
