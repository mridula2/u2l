#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/check-parsed.sh,v 1.8 2014/01/30 06:34:51 morimoto Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.
# It does the following things.
# (1) Extract cmds which exist on PATH of the machine.
#     each cmd line starts with "-" or "+"
#     "-" : command which does not exist.
#     "+" : command which exist.
# (2) List "cmd filename line".
#     each line starts with "--" or "++"
#     "--" : command which does not exit.
#     "++" : command which exist.
# (3) Print actual line which exist the cmd.
#     if environment variable OFFLINE=on, 
#     then it does not print these lines. (add on 2008/04/10)
# (4) Use the command database file instead of actual path(type command).
#     This make it possible to analyze the command availability
#     on other platform ( linke Linux ) if we have the command 
#     database file. The command database file should be extracted
#     like "find /bin /usr/bin /usr/sbin > cmd-db-file".
#     Also, environment variable (XCHECK_FILE) can be used instead
#     of -f option. (added on 2008/11/18)
# NOTE:
#
# History:
# 1. Fix the bug that if number of 'F' is more than 100, 
#    it will print error.(2008/07/04)
# 2. Add -f option (2008/11/18)
# 3. Use '+' instead of '@' and '-' instad of '#'. (2008/11/18)
# 4. FIX : linux's printf command problem : Can't output '-' char

#
# evalute backslash '\' on line end function.
#
# behavior:
#  input:
#	aaaaa \
#	bbbbb \
#	ccccc;
#  output:
#	aaaaa bbbbb ccccc;
#	# <<<< dummy comment line
#	# <<<< dummy commnet line
#
function func_holdbackslash {
	if [ X"$CSHFLG" = X"off" ] ; then
		cat $1
		return
	fi
awk '
/\\$/ {
    line=$0;
    gsub("\\\\$", "", line);
    endback++;
    printf("%s", line);
    next;
}
{
    print $0;
    if ( endback > 0 ) {
        for ( i=0; i < endback ; i++ ) {
            print "#"
        }
        endback=0;
    }
}' $1
}

function func_printOKCmd1 {
# extract command_name and delete '"', '{', '}' charactor
# BUG FIX : BAD results
#           NG: - $FOO_VAR"    4
#           OK: - $FOO_VAR     4
grep "^C " $1| awk '{print $2}'|sed -e 's/"//g' -e 's/{//g' -e 's/}//g' | 
# sort and count unique command_name
sort -f | uniq -c |
# check command is exist
#   by checking PATH or $XCHECK_FILE
while read x y
do
		if [ -z "$XCHECK_FILE" ] ; then
			type $y > /dev/null 2>&1
		else
			grep -q -e \^$y\$  -e /$y\$ $XCHECK_FILE
		fi
		if [ $? -ne 0 ] ; then
			CMD_EXIST='-'   # not exist
		else
			CMD_EXIST='+'   # exist
		fi
		echo "$y $x $CMD_EXIST"
done
}



if [ $# -lt 2 ]
then
    echo "Usage:check-parsed.sh [-f filelist] ksh|csh filename"
    exit 1
fi


if [ "$1" =  "-f" ] ; then
    shift
    XCHECK_FILE=$1
    shift
fi

if [ "$1" = "csh" ]
then
	CSHFLG="on"
	tgtfile=$2
else
	CSHFLG="off"
	TMPDIR=/var/tmp/extnormal1.$$
	TMPFILE1=${TMPDIR}/ex1.$$
	TMPFILE2=${TMPDIR}/ex2.$$
	TMPFILE3=${TMPDIR}/ex3.$$
	mkdir $TMPDIR
	trap 'rm -rf $TMPDIR;exit 1' 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
	grep '^F ' $2 | cut -f2 -d" " | sort | uniq -c |\
	awk '{printf("/^C %s /d\n", $2)}' > $TMPFILE1
	line=`cat $TMPFILE1 | wc -l`
	if [ $line -gt 0 ] ; then
		if [ $line -lt 100 ] ; then
			sed -f $TMPFILE1 $2 > $TMPFILE2
		else
			pwd=`pwd`
			cp $pwd/$2 $TMPFILE2
			cd $TMPDIR
			split -l 99 $TMPFILE1
			for xx in x*
			do
				sed -f $xx $TMPFILE2 > $TMPFILE3
				cp $TMPFILE3 $TMPFILE2
			done
			cd $pwd
		fi
		tgtfile=$TMPFILE2
	else
		tgtfile=$2
	fi
fi



func_printOKCmd1 $tgtfile |
#
# input data format :
#   cmd_name <n> {-|+}
#	cmd_name ... command name	: cmd
#	n ... number of occurrence 	: num
#	+ ... cmd_name is in PATH 	: flag
#	- ... cmd_name is NOT in PATH 	: flag
while read cmd num flag
do
	# Linux's prinf command can't output '-' 
	if [ "$flag" = '-' ];
	then
		printf "\055 %-27s%10d\n" $cmd $num
	else
		printf "$flag %-27s%10d\n" $cmd $num
	fi

	grep '^C ' $2|sed -e 's/^C //' -e 's/"//' -e 's/{//g' -e 's/}//g' |\
	env cmd="$cmd" awk '
BEGIN{
	cmd=ENVIRON["cmd"];
}
{
	if ( cmd == $1 ) {
		print $0;
	}
}' |
# format:
#  <cmd_name> <file_name> <line#>
while read cmd2 fname line
do
	echo "${flag}${flag} $cmd2 $fname $line"
	if [ "X${OFFLINE}" = X"on" ] ; then
		continue
	fi
	# compare backslash line and extract one line.
	func_holdbackslash $fname | sed -ne "${line},${line}p"
done
done

if [ X"${CSHFLG}" = X"off" ] ; then
	rm -rf $TMPDIR
fi
