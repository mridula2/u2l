#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/shanalyze/scriptParamParser.pl,v 1.5 2014/12/25 07:55:28 meguro Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script parse script parameter for parser_out_file.
# parameter : parser_out_file      : [k|c]shparser.sh output file
# output    : stdout               : 1. When parameter is detected, add same line. parameter column set detected parameter.
#                                  :    Original line's parameter set _TOTAL_
#                                  : 2. When parameter is not detected, parameter set _noOption_

use File::Basename;

sub usage {
    return "Usage : " . basename($0) . " parser_out_file \n";
}

if ( @ARGV != 1) {
    die usage;
}

my $parsedOut = $ARGV[0];

if (! -r $parsedOut ) {
    die "file not found.($parsedOut)\n" . usage;
}

open(my $fh, "grep ^C $parsedOut |" ) or die "Cannot open $parsedOut for read: $!";
while(<$fh>) {
	chomp;
	my @line = split(/\t/, $_);
	my $command = $line[2];
#	my @commandList = split(/\|/, @line[6]);
	if(exists($line[6]{/\|/}))
        {
        my @commandList = split(/\|/, @line[6]);
        }
        else
	{
	my @commandList = @line[6];
	} 
 
	my $dCount = 0;
	my $sCount = 0;
	my $on = 0;

	# Escape special character in the command for pattern matching.
	if ( $command eq "[" ) {	# case "["
		$command = "\\[";
	}
	$command =~ s/\./\\\./g;	# case "./cmd"
	$command =~ s/\$/\\\$/g;	# case $var or ${var}
	if ( $command =~ s/{/{\*/g ) {
		$command =~ s/}/}\*/g;
	}

	foreach $aaa (@commandList) {
		$on = 0;
		my @context = split(/ +/, $aaa);
		my @exists = ();
		foreach $val (@context) {
			if ( $val =~ $command ) {
				$on = 1;
				next;
			}
			if ( $on eq 1 && $dCount == 0 && $sCount == 0 ) {
				if ($val =~ /^-([a-zA-Z0-9]+).*/ ) {
					$val = $1;
					$val = "{num}" if ( $val =~ /^\d+$/ );
					$val =~ s/\d+$//;
	
					if ($val eq "") {
						next;
					}
					if (@exists eq 0) {
						print join("\t", @line[0..3])."\t_TOTAL_\t".join("\t", @line[4..$#line-1])."\t".$aaa."\t\n";
					}
					if (! (grep{$_ eq $val} @exists))  {
						print join("\t", @line[0..3])."\t".$val."\t".join("\t", @line[4..$#line-1])."\t".$aaa."\t\n";
						push(@exists, $val);
					}
				} else {
					$val =~ s/\\"//g;
					$dCount = ($dCount + (() = $val =~ /\"/g)) % 2;
					$val =~ s/\\'//g;
					$sCount = ($sCount + (() = $val =~ /\'/g)) % 2;
				}
			} elsif ($dCount > 0) {
				$val =~ s/\\"//g;
				$dCount = ($dCount + (() = $val =~ /\"/g)) % 2;
			} elsif ($sCount > 0) {
				$val =~ s/\\'//g;
				$sCount = ($sCount + (() = $val =~ /\'/g)) % 2;
			}
		}
		if ($on eq 1 && @exists eq 0) {
			print join("\t", @line[0..3])."\t_noOption_\t".join("\t", @line[4..$#line-1])."\t".$aaa."\t\n";
		}
	}
}

close $fh;

