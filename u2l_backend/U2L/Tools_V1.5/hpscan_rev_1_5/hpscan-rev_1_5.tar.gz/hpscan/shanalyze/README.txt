# $Header: /data/cvsrepo/hpscan/shanalyze/README.txt,v 1.7 2013/09/02 06:59:05 hmizuno Exp $
# 2013/8/27 marge log from assess00 and assess01

check-parsed.sh
    check-parsed.sh_1.1 .... original 1.1 version
    check-parsed.sh_1.2 .... tempolary version
    check-parsed.sh_1.3 .... original 1.3 version
    check-parsed.sh_1.4 .... new version from assess01 linux server

cshparser.sh
    cshparser.sh_1.1 .... original version in cvs
    cshparser.sh_1.2 .... original version in cvs
    cshparser.sh_1.3 .... original version in cvs
    cshparser.sh_1.4 .... new version from assess00(hpux) and assess01(linux)

extnormal.sh
    extnormal.sh_1.3 .... original version in cvs
    extnormal.sh_1.4 .... add shell command header for linux and hpux

findspecical.sh
    findspecical.sh_1.2 .... original version in cvs
    findspecical.sh_1.3 .... add shell command header for linux and hpux

kshparser.sh
    kshparser.sh_1.4 .... original version in cvs
    kshparser.sh_1.5 .... add shell command header for linux and hpux

listshells.sh
    listshells.sh_1.2 .... original version in cvs
    listshells.sh_1.3 .... add shell command header for linux and hpux
                      .... fix : support linux platform

shparser.sh
    shparser.sh_1.3 .... original version in cvs
    shparser.sh_1.4 .... add shell command header for linux and hpux
