#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/extractHereDocument.sh,v 1.1 2013/12/10 09:23:41 morimoto Exp $
# (C) 2013 Hewlett-Packard Development Company, L.P.

usage(){
        echo "usage:`basename $0` script_file_list [aix|linux]"
        exit 1
}

if [ $# -ne 1 ]; then
        usage
fi

FILE_LIST=$1
if [ ! -r ${FILE_LIST}  ] ; then
        echo "file:${FILE_LIST} cannot read."
        exit 1
fi

cat ${FILE_LIST} | while read fileName
do
	echo "checking:${fileName}" 1>&2
	grepResult=`grep -n "<<" $fileName | grep -v "^[ ]*#"`
	if [ -n "${grepResult}" ] ; then
		echo "${grepResult}" | sed -e 's/\t/ /g' | sed -e 's/\([0-9]\+\):/\t\1\t/g' -e 's#^#HEREDOC\t'"${fileName}"'#g'
	fi
done

