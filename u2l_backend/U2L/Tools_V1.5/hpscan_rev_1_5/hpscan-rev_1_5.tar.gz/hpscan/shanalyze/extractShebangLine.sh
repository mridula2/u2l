#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/extractShebangLine.sh,v 1.3 2016/08/26 09:02:16 meguro Exp $
# (C) 2013 Hewlett-Packard Development Company, L.P.

usage () {
	echo "usage:`basename $0` script_file_list"
	exit 1
}

if [ $# -ne 1 ] ; then
	usage
fi

FILE_LIST=$1
cat ${FILE_LIST} | while read fileName
do
	echo "checking:${fileName}" 1>&2
	shebang=`head -1 ${fileName} | awk '$0 ~ /^#!/'`
	echo "${shebang}	${fileName}"
done

