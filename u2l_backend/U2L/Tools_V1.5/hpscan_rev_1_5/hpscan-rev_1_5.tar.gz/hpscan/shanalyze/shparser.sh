#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/shparser.sh,v 1.5 2014/01/30 06:34:52 morimoto Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.

PATH=$PATH:.   # to avoid the bug of shanalizer(kshparser)
unset HOME     # to avoid the bug of shanalizer(kshparser)
if [ -z "$HPSCAN" ] ; then
    SH_TOP=${SH_TOP:-/usr/local/hpscan/shanalyze}
else
    SH_TOP=$HPSCAN/shanalyze
fi
export SH_TOP

for x in $*
do
	file $x | grep "commands text" > /dev/null 2>&1
	if [ $? -ne 0 ] ; then continue; fi
	head=`head -1 $x`
	echo $head | grep bin/csh > /dev/null 2>&1
	if [ $? -eq 0 ] ; then
		$SH_TOP/cshparser.sh $x
		continue;
	fi
	echo $head | grep -e bin/sh -e bin/ksh > /dev/null 2>&1
	if [ $? -eq 0 ] ; then
		 $SH_TOP/kshparser.sh $x
		continue; 
	fi
done
