#!/bin/sh

# $Header: /data/cvsrepo/hpscan/shanalyze/parserOutputCheck.sh,v 1.3 2014/12/25 07:55:28 meguro Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P. 
# This is check script for kshparser.sh and cshparser.sh output file.
#
# usage     : parserOutputCheck.sh parsed_out_file [ignore_command_list_file]
# parameter : parsed_out_file           : kshparser.sh and cshparser.sh output file
#           : ignore_command_list_file  : ignore command list file
#                                       : if ignore all command in under /usr/local/hpscan, write /usr/local/hpscan/

usage () {
	echo "usage: `basename $0` parsed_out_file [ignore_command_list_file]"
	exit 1
}

inputFile=""
ignoreFile=""

# check parameter
if [ $# -eq 1 ] ; then
	inputFile=$1
elif [ $# -eq 2 ] ; then 
	inputFile=$1
	ignoreFile=$2
else
	usage
fi

if [ ! -r ${inputFile} ] ; then
	echo "No such file : ${inputFile}"
	exit 1
fi

if [ -n "${ignoreFile}" ] && [ ! -r ${ignoreFile} ] ; then
	echo "No such file : ${ignoreFile}"
	exit 1
fi

# exclude C [      : test evaluate
grep -n -v -e "^C	CMD	\[	" ${inputFile} | 
awk '
BEGIN{
	FS="	"
	num=0
	if ( "'$ignoreFile'" != "" ) {
		while ( (getline line < "'$ignoreFile'") > 0) {
			ignores[num+1]=line
			num++
		}
	}
}
{
	err=""
	command=$3
	# shparser warning
	if ( $1 ~ "[0-9]*:W" ) {
		print "WARNING:	 " $0
	# . : is builtin command
	} else if ( command == "." || command == ":" ) {
		next
	# contains backslash
	} else if ( command ~ /\\/) {
		err="REPORT \\COMMAND:	" $0
	# contains space
	} else if ( command ~ /[ ]+/) {
		err="CHECK COMMAND: " $0
	# contains not allowed characters
	} else if ( command ~ /[^.\/_a-zA-Z0-9]/ ) {
#printf("%05i %s\n", NR, command);
		# $... or ${...} or "${...}"
		if ( command ~ /\$[_a-zA-Z0-9]*/  || command ~ /\$\{[_a-zA-Z0-9]*\}/) {
			next
		# other case
		} else {
			#err="CHECK COMMAND:	" $0
		}
	}
	if ( err != "" ) {
		find=0
		for (i=0;i<num;i++) {
			tmp=ignores[i+1]
			if ( command ~ tmp ) {
				find=1
				break;
			}
		}
		if (find == 0) {
				print err
		}
	}
}'
