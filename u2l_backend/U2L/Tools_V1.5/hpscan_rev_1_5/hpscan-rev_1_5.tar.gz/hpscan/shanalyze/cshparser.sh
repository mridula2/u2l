#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/cshparser.sh,v 1.12 2016/09/02 10:18:56 meguro Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P. 
# This i a wrapper for 'cshparser'.
# It adds some more functions to cshparser.
#   1) Handle here document
#   2) Handle multiple lines separated by back slash.
#   3) Extract command[s] within back quotation
#   4) Extract command[s] within curly brace.


function func_cutheredoc {
  # at first, eliminate string quotation in order not to handle ''<<'
  # within string quotation as here document.
  # It cannot handle non-ASCII text

###########################################
# Changed by miya 2010.12.09
# To handle Japanese text 

# 2013.08.27
# support Linux and hp-ux platform

# orginal #
#sed -e 's/^[ 	]*#.*$//' \
#-e "s/\'[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\.{}() 	]*\'/\'\'/g" \
#-e 's/"[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\.{}() 	]*"/""/g' |

case `uname -s` in
Linux )
  sed -e 's/^[:space:]*#.*$//' \
    -e "s/'[^\"'\$\`~[:cntrl:]]*'/''/g" \
    -e 's/"[^\"'"'"'\$\`~[:cntrl:]]*"/""/g'
  ;;
HP-UX | * )
  sed -e 's/^[[:space:]]*#.*$//' \
    -e "s/\'[^\"\'\$\`~[[:cntrl:]]]*\'/\'\'/g" \
    -e 's/"[^\"'"'"'\$\`~[[:cntrl:]]]*"/""/g'
  ;;
esac | \
awk '{
    # search line contains heredoc <<
    if (match($0,"<<")) {
        split($0, to, /<</);
        left=to[2];
        gsub("^[ \t]*","",left);
        # if left string is <<tgt>> ..., heredoc keyword is tgt
        # to extract heredoc keyword, remove >
        gsub(">"," ",left);
        # extract heredoc keyword
        split(left, key);
        tgt=key[1];
        # eliminate begin heredoc keyword from left string
        gsub("^"tgt, "", left);
        # if heredoc keyword is in same line
        if (match(left, tgt)) {
            gsub(".*"tgt, "", left);
            print to[1] left;
        } else {
            # search heredoc end line
            print to[1];
            getline;
            while (match($0, tgt) != 1) {
                print "";
                getline;
                gsub("^ *", "");
                gsub("^\t*", "");
            }
            print "";
        }
    } else {
        print;
    }
}'
}
function func_holdbackslash {
awk '
/\\$/ {
    line=$0;
    gsub("\\\\$", "", line);
    endback++;
    printf("%s", line);
    next;
}
{
    print $0;
    if ( endback > 0 ) {
        for ( i=0; i < endback ; i++ ) {
            print "#"
        }
        endback=0;
    }
}' $1
}

function func_parsebackquote {
	export FNAME="$1"
    #grep -v '^[    ]*#.*' | grep -n \` $x |\
    sed 's/^[ 	]*#.*$//' $FNAME | grep -n \` |\
    sed -n \
        -e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4\
\1 \5\
\1 \6/p' \
        -e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4\
\1 \5/p' \
        -e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3\
\1 \4/p' \
        -e 's/^\([0-9]*\):.*`\(.*\)`.*`\(.*\)`.*/\1 \2\
\1 \3/p' \
        -e 's/^\([0-9]*\):.*`\(.*\)`.*/\1 \2/p' \
        -e 's/^\([0-9]*\):\([^`]*`[^`]*$\)/\1 `notclosed \2/p' > $TMPFILE
    wc=`cat $TMPFILE|wc -l`
    if [ $wc -ne 0 ] ; then
        #/usr/bin/env FNAME="$x" | awk '{printf("C %s %s %s\n", $2,ENVIRON["FNAME"],$1)}' $TMPFILE
		func_print_othercmd $TMPFILE
    fi
	rm -f $TMPFILE
}

function func_parsecurlybrace {
	export FNAME="$1"
    #grep -v '^[    ]*#.*' | grep -n \` $x |\
sed -e 's/^[ 	]*#.*$//' \
-e "s/\'[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\.{}() 	]*\'/\'\'/g" \
-e 's/"[-a-zA-Z0-9_<>=,:;|#@\!\?\%\&\*\+\/\[\^\.{}() 	]*"/""/g' $1|
    grep -n \{ |\
    sed -n 's/^\([0-9]*\):\(.*\){ \(.*\) }\(.*\)$/\1 \3/gp' | sed 's/(//g' > $TMPFILE
    wc=`cat $TMPFILE|wc -l`
    if [ $wc -ne 0 ] ; then
        #/usr/bin/env FNAME="$x" | awk '{printf("C %s %s %s\n", $2,ENVIRON["FNAME"],$1)}' $TMPFILE
		func_print_othercmd $TMPFILE
    fi
	rm -f $TMPFILE
}

function func_print_othercmd {
awk '{
	linenum=$1;
	line=$0;
	if ( $2 == "`notclosed" ) {
		printf("W `notclosed %s %s\n", ENVIRON["FNAME"], linenum)
		next
	}
	flag=0;
	gsub("^[0-9]* ","",line);
	num=split(line, ary, "|");
	for (i=0; i<num; i++) {
		tgt=ary[i+1];
		gsub("^[ 	]", "", tgt);
		split(tgt, ary2, " ");
		if ( flag == 0 ) {
			cmd=ary2[1];
			printf("C\tCMD\t%s\t\t%s\t%s\t%s\n", cmd,ENVIRON["FNAME"],linenum,tgt)
		}
		if ( tgt ~ /.*\"|\047.*/ ) {
			tmp=tgt
			gsub(/\\\"/,"  ",tmp);
			gsub(/\\\047/,"  ",tmp);
			if ( (gsub("\"|\047"," ",tmp) % 2) == 1 ) {
				flag=!flag;
			}
		}
	}
}' $1
}


TMPFILE=/var/tmp/back.$$
trap 'rm -f $TMPFILE;exit 1' 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

if [ -z "$HPSCAN" ] ; then
    SH_TOP=${SH_TOP:-/usr/local/hpscan/shanalyze}
else
    SH_TOP=$HPSCAN/shanalyze
fi

unset HOME
PATH=$PATH:.

for x in $*
do
	func_holdbackslash $x | func_cutheredoc | env LS_COLORS= $SH_TOP/cshparser.sh |
	/usr/bin/env FNAME="$x" \
	awk '{printf("%s %s %s %s\n",$1,$2,ENVIRON["FNAME"],$3)}' |
	while read type cmd file line
	do
		# remove this process to get line from source file, when cshparser can output parsed line.
		# modify awk printf format
		printf "%s\tCMD\t%s\t\t%s\t%s\t" ${type} ${cmd} ${file} ${line}
		func_holdbackslash $x | sed -ne "${line},${line}p" |
		sed -E "s/^[\t ]+//" | sed -E "s/[\t ]+$//" | sed -E "s/[\t ]+/ /g"
	done
	func_parsebackquote $x
	func_parsecurlybrace $x
done
