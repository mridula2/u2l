#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/extnormal.sh,v 1.5 2014/01/30 06:34:52 morimoto Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.
# It does the following things.
# (1) Extract cmds which exist on PATH of the machine.
#     each cmd line starts with "#"
# (2) List "cmd filename line".
#     each line starts with "##"
# (3) Print actual line which exist the cmd.
#     if environment variable OFFLINE=on, 
#     then it does not print these lines. (add on 2008/04/10)
# NOTE:
#   If envirnonment variable CMD_REVERSE=on, then it extracts
#   cmds which DOES NOT exist on PATH of the machine. 
#   Other points is the same as above.
#
# History:
# 1. Fix the bug that if number of 'F' is more than 100, 
#    it will print error.(2008/07/04)


function func_holdbackslash {
	if [ X"$CSHFLG" = X"off" ] ; then
		cat $1
		return
	fi
awk '
/\\$/ {
    line=$0;
    gsub("\\\\$", "", line);
    endback++;
    printf("%s", line);
    continue;
}
{
    print $0;
    if ( endback > 0 ) {
        for ( i=0; i < endback ; i++ ) {
            print "#"
        }
        endback=0;
    }
}' $1
}

function func_printOKCmd1 {
grep "^C " $1| awk '{print $2}'|sed -e 's/"//' -e 's/{//g' -e 's/}//g' | 
sort -f | uniq -c |
while read x y
do
#	echo "$y $x"
	if [ "X${CMD_REVERSE}" = X"on" ] ; then
		type $y > /dev/null 2>&1
		if [ $? -ne 0 ] ; then
			echo "$y $x"
		fi
	else
		type $y > /dev/null 2>&1
		if [ $? -eq 0 ] ; then
			echo "$y $x"
		fi
	fi
		
done
}


if [ $# -lt 2 ]
then
    echo "Usage:extnomal.sh [ksh|csh] filename"
    exit 1
fi


if [ "$1" = "csh" ]
then
	CSHFLG="on"
	tgtfile=$2
else
	CSHFLG="off"
	TMPDIR=/var/tmp/extnormal1.$$
	TMPFILE1=${TMPDIR}/ex1.$$
	TMPFILE2=${TMPDIR}/ex2.$$
	TMPFILE3=${TMPDIR}/ex3.$$
	mkdir $TMPDIR
	trap 'rm -rf $TMPDIR;exit 1' 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
	grep '^F ' $2 | cut -f2 -d" " | sort | uniq -c |\
	awk '{printf("/^C %s /d\n", $2)}' > $TMPFILE1
	line=`cat $TMPFILE1 | wc -l`
	if [ $line -gt 0 ] ; then
		if [ $line -lt 100 ] ; then
			sed -f $TMPFILE1 $2 > $TMPFILE2
		else
			pwd=`pwd`
			cp $pwd/$2 $TMPFILE2
			cd $TMPDIR
			split -l 99 $TMPFILE1
			for xx in x*
			do
				sed -f $xx $TMPFILE2 > $TMPFILE3
				cp $TMPFILE3 $TMPFILE2
			done
			cd $pwd
		fi
		tgtfile=$TMPFILE2
	else
		tgtfile=$2
	fi
fi



func_printOKCmd1 $tgtfile |
while read x y
do
	printf "# %-27s%10d\n" $x $y
	grep '^C ' $2|sed -e 's/^C //' -e 's/"//' -e 's/{//g' -e 's/}//g' |\
	env x="$x" awk '
BEGIN{
	x=ENVIRON["x"];
}
{
	if ( x == $1 ) {
		print $0;
	}
}' |
while read a b c
do
	echo "## $a $b $c"
	if [ "X${OFFLINE}" = X"on" ] ; then
		continue
	fi
	func_holdbackslash $b | head -$c | tail -1
done
done

if [ X"${CSHFLG}" = X"off" ] ; then
	rm -rf $TMPDIR
fi
