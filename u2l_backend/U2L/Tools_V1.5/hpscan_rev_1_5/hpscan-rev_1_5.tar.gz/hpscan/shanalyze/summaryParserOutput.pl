#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/shanalyze/summaryParserOutput.pl,v 1.4 2014/12/25 07:55:29 meguro Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.
# This script create command summary data from parser output file.
# parameter : parser_out_file      : [k|c]shparser.sh output file
#           : source_dir           : directory execute [k|c}shparser.sh
# option    : -s std_cmd_db_file   : command list located in /bin /usr/bin /usr/sbin
#                                    if not specified, use /usr/local/hpscan/shanalyze/stdCmdDb.list
#           : -o other_cmd_db_file : middleware command list already known
#                                    if not specified, use /usr/local/hpscan/shanalyze/otherCmd.list
#           : -p                   : print total count per command type

use File::Find;
use File::Basename;
use Getopt::Long;

# command list cvs file : index for command type
use constant INDEX_COMMAND_TYPE => 1;
# command list cvs file : index for needs modify?
use constant INDEX_NEED_MOD => 2;

$dirname = dirname($0);

sub usage {
	return "Usage : " . basename($0) . " [-p] [-s std_cmd_db_file ] [-o other_cmd_db_file] parser_out_file source_dir.\n";
}

my $uname = `uname`;
chomp($uname);
my $stdCmdDbFile = $dirname."/stdCmdDb_" . $uname .".list";
my $otherCmdDbFile = $dirname."/otherCmd.list";
my $printTotal;

GetOptions('std_cmd_db_file=s' => \$stdCmdDbFile, 'other_cmd_db_file=s' => \$otherCmdDbFile, 'printTotal' => \$printTotal) or die usage;

if ( @ARGV != 2) {
	die usage;
}

my $parsedOut = $ARGV[0];
my $sourceDir = $ARGV[1];

if (! -r $stdCmdDbFile) {
	die "file not found.($stdCmdDbFile)\n" . usage;
}

if (! -r $otherCmdDbFile) {
	die "file not found.($otherCmdDbFile)\n" . usage;
}

if (! -r $parsedOut) {
	die "file not found.($parsedOut)\n" . usage;
}

if (! -d $sourceDir) {
	die "source directory not found.($sourceDir)\n" . usage;
}

my %commandCount = ();
my %commandTypeCount = ();
my %commandAppearance = ();
my @files;

readParsedOut();
find (\&createSrcFileList, $sourceDir);
my %unixCmdList = readCsvFile($stdCmdDbFile);
my @unixCmdKeys = keys(%unixCmdList);
my %otherCmdList = readCsvFile($otherCmdDbFile);

foreach $keyString (sort keys %{$commandCount{"C"}}) {
	@com_valuedCom = split(/\t/, $keyString);
	if ( $com_valuedCom[1] ne "" ) {
		$command = $com_valuedCom[1];
	} else {
		$command = $com_valuedCom[0];
	}
        if ($command eq "")
	{
           last;
	} 
	$filename = basename($command);
	$commandType = "Other";
	$needModify = "";

	# in case command is in stdCmd(etc. /bin /usr/bin)
	if (@{$unixCmdList{$command}}) {
		$commandType = @{$unixCmdList{$command}}[INDEX_COMMAND_TYPE];
		$needModify = @{$unixCmdList{$command}}[INDEX_NEED_MOD];

	} else {
		foreach $checkCmd (@unixCmdKeys) {
			# in case command is not fullpath
			if ( $checkCmd = !""  && $checkCmd =~ /\/$command$/) {
				$commandType = @{$unixCmdList{$checkCmd}}[INDEX_COMMAND_TYPE];
				$needModify = @{$unixCmdList{$checkCmd}}[INDEX_NEED_MOD];
				break;

			# in case command is in other path in assessment enviroment
			} elsif ( $checkCmd =~ /\/$filename$/  ) {
				$commandType = "CmdModPath";
				$needModify = "needModify";
				break;

			}
		}
	}

	# in case not detected in std command path
	if ($needModify eq "") {
		# in case command is in user function
		if ( $commandCount{'F'}{$keyString} > 0 ) {
			$commandType = "UserFunc";
			$needModify = "noProblem";

		# in case command is in user script
		} elsif ( findUserProgram()) {
			$commandType = "UserProgram";
			$needModify = "noProblem";

		# in case command is in known middleware command list
		} elsif ($otherCmdList{$filename}) {
			$commandType = @{$otherCmdList{$filename}}[INDEX_COMMAND_TYPE];
			$needModify = @{$otherCmdList{$filename}}[INDEX_NEED_MOD];

		# unknown command
		} else {
			$commandType = "Other";
			$needModify = "commandSurvey";
		}
	}

	printf("%s\t%s\t%d\t%s\n", $commandType, $keyString, $commandCount{'C'}{$keyString}, $needModify);
	$commandTypeCount{$commandType}++;
	$commandAppearance{$commandType} += $commandCount{'C'}{$keyString};
}

# option -p
if ($printTotal) { 
	printf("\n=========== commandType summary ===========\n");
	printf("%-15s\t%10s\t%10s\n", "commandType", "count", "appearance");
	printf(  "-------------------------------------------\n");
	my %total = ();
	foreach $commandType (sort keys %commandTypeCount) {
		printf("%-15s\t%10d\t%10d\n", $commandType, $commandTypeCount{$commandType}, $commandAppearance{$commandType});
		$total{'commandTypeCount'} += $commandTypeCount{$commandType};
		$total{'commandAppearance'} += $commandAppearance{$commandType};
	}
	printf(  "-------------------------------------------\n");
	printf("%-15s\t%10d\t%10d\n", "total", $total{'commandTypeCount'}, $total{'commandAppearance'});
}

sub createSrcFileList {
	# add only file to array
	if (-f $_) {
		push(@files, $File::Find::name);
	}
}

sub findUserProgram {
	foreach (@files) {
		if ($checkCmd = !"" && $_ =~ /^.*\/$filename$/) {
			return true;
		}
	}
}

sub readParsedOut {
	open(my $fh, "<", $parsedOut) or die "Cannot open $parsedOut for read: $!";
	while(<$fh>) {
		chomp;
		my @line = split(/\t/, $_);
		$line[2] =~ s/\\//;		
		# summary per "command\tvaluedCommnad"
		$commandCount{$line[0]}{$line[2] . "\t" . $line[3]}++;
	}
	close $fh;
}

sub readCsvFile {
	my $filename = shift;
	open(my $fh, "<", $filename) or die "Cannot open $filename for read: $!";
	my %retArray = ();
	while(my $line = <$fh>) {
		chomp ($line);
		if ($line =~ /^\#/) {
			 next;
		}
		my @items = split(/,/, $line);
		@{$retArray{$items[0]}} = @items;
	}
	close $fh;

	return %retArray;
}

