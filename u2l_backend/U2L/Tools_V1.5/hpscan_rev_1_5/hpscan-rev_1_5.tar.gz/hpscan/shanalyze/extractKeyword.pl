#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/shanalyze/extractKeyword.pl,v 1.1 2014/04/01 06:39:34 morimoto Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# extract keyword from file written file_list.
# parameter : file_list      : shell assessment file list
#           : keyword_list   : extract keyword

use File::Basename;

my $fileList = $ARGV[0];
my $keyList = $ARGV[1];

sub usage {
    return "Usage : " . basename($0) . " file_list key_list\n";
}

if ( @ARGV != 2) {
    die usage;
}

if (! -r $fileList) {
    die "file not found.($fileList)\n" . usage;
}
if (! -r $keyList) {
    die "file not found.($keyList)\n" . usage;
}

@keyWords = ();
{
	open(my $fh, "<", $keyList) or die "Cannot open $keyList for read: $!\n";
	while(<$fh>) {
		chomp;
		push(@keyWords, $_);
	}
	close($fh);
}

open(my $fh, "<", $fileList) or die "Cannot open $fileList for read: $!\n";
while ($fileName=<$fh>) {
	chomp($fileName);

	print STDERR "$fileName\n";

	open(my $targetFile, "<", $fileName) or print STDERR "Cannot open $fileName for read: $!\n"; 
	while ($line=<$targetFile>) {
		foreach $key (@keyWords) {
			if ($line =~ /$key/) {
				$line =~ s/\t/ /g;
				print STDOUT "$key\t$fileName\t$.\t$line";
			}
		}
	}
	close($targetFile);

}
close($fh);

