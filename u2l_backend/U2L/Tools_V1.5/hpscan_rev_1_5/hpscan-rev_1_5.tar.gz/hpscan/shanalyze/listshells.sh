#!/bin/sh
# $Header: /data/cvsrepo/hpscan/shanalyze/listshells.sh,v 1.4 2014/01/30 06:34:52 morimoto Exp $
# (C) 2008 Hewlett-Packard Development Company, L.P.

OS_NAME=`uname -s`

for x in $*
do

case "$OS_NAME" in
HP-UX )
	file $x | grep "commands text" > /dev/null 2>&1
	if [ $? -ne 0 ] ; then echo "ot1 $x"; continue; fi

	head=`head -1 $x`
	echo $head | grep bin/csh > /dev/null 2>&1
	if [ $? -eq 0 ] ; then echo "csh $x"; continue; fi
	echo $head | grep bin/sh > /dev/null 2>&1
	if [ $? -eq 0 ] ; then echo "bsh $x"; continue; fi
	echo $head | grep bin/ksh > /dev/null 2>&1
	if [ $? -eq 0 ] ; then echo "ksh $x"; continue; fi
	echo "ot2 $x"
  ;;

Linux | * )
        out=`file $x`
        echo $out | grep -q 'script'
                if [ $? -ne 0 ] ; then echo "ot1 $x"; continue; fi

        echo $out | grep -q -e 'C shell' -e bin/csh
                if [ $? -eq 0 ] ; then echo "csh $x"; continue; fi
        echo $out | grep -q -e 'Bourne-Again shell' -e 'POSIX shell' -e bin/sh -e 'Bourne shell'
                if [ $? -eq 0 ] ; then echo "bsh $x"; continue; fi
        echo $out | grep -q -e 'Korn shell' -e bin/ksh
                if [ $? -eq 0 ] ; then echo "ksh $x"; continue; fi
        echo "ot2 $x"
  ;;

esac

done
