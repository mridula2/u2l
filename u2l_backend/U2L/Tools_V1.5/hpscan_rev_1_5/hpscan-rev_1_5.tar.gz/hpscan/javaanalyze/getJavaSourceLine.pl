#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/javaanalyze/getJavaSourceLine.pl,v 1.2 2014/05/27 07:37:22 morimoto Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script get file context from list_file. Do this script in source root direcotry.
# input     : list_file : id<tab>message<tab>filename<tab>linenum
# output    :             id<tab>message<tab>filename<tab>linenum<tab>context

use File::Basename;

sub usage {
	print "Usage : " . basename($0) . " list_file\n";
	print "list_file format : id<tab>message<tab>filename<tab>linenum\n";
	exit 1;
}

if ( @ARGV != 1) {
	usage;
}

my $inputFile = $ARGV[0];

if (! -r $inputFile) {
	print "file not found.($inputFile)\n";
	usage;
}

open($fh,"<", $inputFile) or die  "Can't open $filename: $!";
while (my $line = <$fh>) {
	chomp($line);
	(my $id, my $msg, my $fileName, my $lineNum) = split(/\t/, $line);

	print $line . "\t";
	my $find = 0;
	open($sfh, "<", $fileName) or die "Can't open $vars[0]";
	while (<$sfh>) {
		if ( $. == $lineNum) {
			chomp($_);
			$_ =~ s/\t/ /g;
			print $_."\n";
			$find = 1;
			last;
		}
	}
	if ($find == 0) {
		print "\n";
	}
	close($sfh);
}
close($hf);

