#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/javaanalyze/extractImportLines.pl,v 1.2 2016/01/22 01:37:07 kozeni Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script detect import packages for target java files written input parameter.
# parameter : java_flie_list : file list for java
# output    : stdout         : <import package name><tab><file name>

use File::Basename;

sub usage() {
	die "usage : " . basename($0) . " java_file_list\n";
}

if ( @ARGV != 1) {
	usage;
}

my $inputFilename=$ARGV[0];

my $check = 1;
open (my $inputfh, "<", $inputFilename) or die "Can't read file : $inputFilename\n$!";
while (my $fileName = <$inputfh>) {
	chomp($fileName);
	open (my $detailfh, "<",$fileName) or die "Can't read file : $fileName\n$!";
	while (my $line = <$detailfh>) {
		extractImportPackageName($fileName, $line, $.);
	}
	close($detailfh);
}
close ($inputfh);

# exctract package name from a line begin with import
sub extractImportPackageName() {
	my $fileName = shift;
	my $line = shift;
	my $lineNum = shift;
	chomp($line);

	# chekc flag is on, and if detect "import".
	if($check eq 1 && $line =~ /^[ \t]*import[ \t]+.*;/) {
		$packageName = substr($line, 0, index($line, ";"));
		$packageName =~ s/[ \t]*import[ \t]*//;

		$line =~ s/^[ \t]*import[ \t]*$packageName;//;
		
		$packageName =~ s/\t/ /;
		printf "%s\t%s\t%d\n", $packageName, $fileName, $lineNum;

		# if there is remain string, after remove detected import package name.
		if (length($line) gt 0) {
			extractImportPackageName($fileName, $line, $lineNum);
		}

	# closed one line comment : ex) /* context */
	} elsif ($line =~ /\/\*.*\*\//) {
		@next = split(/\/\*.*\*\//, $line);
		# if there is some string to the end than "/* commnet */". ex) /* comment */import java...
		if ( $#next gt 0 ) {
			extractImportPackageName($fileName, @next[1..$#next], $lineNum);
		}

	# begin comment  : ex) /*
	# check flag set off
	} elsif ($line =~ /\/\*/) {
		$check = 0;

	# end comment    : ex) */
	# check flag set on
	} elsif ($line =~ /\*\//) {
		$check = 1;
		@next = split(/\*\//, $line);
		# if there is some string to the end than "*/". ex) */import java...
		if ( $#next gt 0 ) {
			extractImportPackageName($fileName, @next[1..$#next], $lineNum);
		}
	}
}

