#!/usr/bin/perl
#
# $Header: /data/cvsrepo/hpscan/javaanalyze/listJavaWarnReport.pl,v 1.1 2014/05/27 07:06:07 morimoto Exp $
# $Name: rev_1_4 $
#
# script name : listJavaWarnReport.pl
# description : get internal warning id from javac warning message
# execute     : listJavaWarnReport.pl warning_list_file
# ipnut	      : log :
#       <javac warning message>\t<dir>\t<file name>\t<line num>
# output      : 
#       <javac warning id>\t<javac warning message>\t<file path>\t<line num>

use File::Basename;

#my $lang = $ENV{LANG};
#$lang = substr($lang, index($lang, ".") + 1);
$dirname = dirname($0);
my $datafile="$dirname/warning_report/javacIssues.data";
my %wdata;
my %regdata;
my %cont;
my @ids;

# Read javac warning message data file.
open my $fh1, "$datafile" || die("Can't open $ARGV[0]");
while(<$fh1>) {
	chomp;
	next if (/^\#/);  # skip comment
	next if (/^$/);   # skip empty line

	if (/^(.*[0-9-]+)\t(.*)\t(.*)/) {
		my $id = $1;
		$wdata{$1} = $2;
		$cont{$1} = $3;
		push(@ids, $id);
		$regdata{$id} = $3;
		$regdata{$id} =~ s/\\/\\\\/g;
		$regdata{$id} =~ s/\#/\\\#/g;
		$regdata{$id} =~ s/\&/\\\&/g;
		$regdata{$id} =~ s/\|/\\\|/g;
		$regdata{$id} =~ s/\//\\\//g;
		$regdata{$id} =~ s/\*/\\\*/g;
		$regdata{$id} =~ s/\(/\\\(/g;
		$regdata{$id} =~ s/\)/\\\)/g;
		$regdata{$id} =~ s/ X / \\d\+ /g;
		$regdata{$id} =~ s/'X'/'\\S'/g;
		$regdata{$id} =~ s/ X\\\)/ \\d\+\\)/g;
		$regdata{$id} =~ s/XXXX/[\\S<>, ()_*]+/g;
	} else {
		print "Incorrect format in $. ($datafile)\n";
		exit 1;
	}
}
close($fh1);

if ($#ARGV != 0) {
	print "Usage : $0 log\n";
	exit 1
}

if (! (defined($ARGV[0]) || -f "$ARGV[0]")) {
	print "Not found $ARGV[0]\"\n";
	exit 1
}

open my $fh, "$ARGV[0]" || die("Can't open $ARGV[0]");

my $wcount=0;
while(<$fh>) {
	(my $wmsg, my $dir, my $file, my $line) = split(/\t/, $_);
    my $wfile = $dir."/".$file;
    my $found = 0;
	if ($line =~ /.* ([0-9]+)/) {
		$line = $1;
	}

    $wmsg =~ s/^\s+//;
    my @wmsg1 = split(/ /,$wmsg);
    my @wmsg2 = split(/\[/,$wmsg1[0]);
    my @wmsg3= split(/\]/,$wmsg2[1]);
    my $wmsgf=substr $wmsg3[0], 0, 6;

    foreach my $wid (@ids) {
                if( index( $regdata{$wid},$wmsgf) != -1)
                  {
                     $found = 1;
                        $wcount = $cont{$wid};
                        my $wout = $wid;
                        print "$wout\t$wmsg\t$wfile\t$line\n";
                        last;
		}
    }
    if ($found == 0) {
		if ($wcount > 0) {
			$wcount--;
			next;
		} else {
			print STDERR "Error: Not found \"$wmsg\" ($.)\n";
			exit 1;
		}
    }
}

close($fh);

