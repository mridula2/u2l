#!/usr/bin/perl

# $Header: /data/cvsrepo/hpscan/javaanalyze/createImportSummaryReportData.pl,v 1.1 2014/05/08 01:28:38 morimoto Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
# This script create import package data for summary report.
# usage     : createImportSummaryReportData.pl -b base_version -n next_version extract_import_file source_dir
# parameter : extract_import_file : import package file what extractImportLines.pl output
#           : source_dir          : java assessment target files
# option    : -b                  : jdk version before the migration
#           : -n                  : jdk version after the migration

use File::Find;
use File::Basename;
use Getopt::Long;

sub usage() {
	return "usage: " . basename($0) . " -b base_version -n next_version extract_import_file source_dir\n".
		"available version : 1.2, 1.3, 1.4.0, 1.4.1, 1.4.2, 5, 6, 7, 8\n";
}

my $inputBaseVer;
my $inputNextVer;
GetOptions('base_version=s' => \$inputBaseVer, 'next_version=s' => \$inputNextVer) or die usage;

if (@ARGV != 2) {
	die usage;
}
if ($inputBaseVer eq "") {
	print STDERR "base_version is Required.\n";
	die usage;
}
if ($inputNextVer eq "") {
	print STDERR "next_version is Required.\n";
	die usage;
}

my $inputFile = $ARGV[0];
if (! -r $inputFile) {
	die "file not found.($inputFile)\n" . usage;
}

my $sourceDir = $ARGV[1];
if (! -d $sourceDir) {
	die "source directory not found.($sourceDir)\n" . usage;
}

$dirname = dirname($0);
$baseFileName = $dirname . "/jdk_list/std_jdk_" . $inputBaseVer . "_list.txt";
$nextFileName = $dirname . "/jdk_list/std_jdk_" . $inputNextVer . "_list.txt";
if (! -r $baseFileName) {
	die "file not found.($baseFileName)\n" . usage;
}
if (! -r $nextFileName) {
	die "file not found.($nextFileName)\n" . usage;
}

my @files;
find ({wanted => \&createSrcFileList, follow => 1}, $sourceDir);
my @basePackage = readPackageData($baseFileName);
my @nextPackage = readPackageData($nextFileName);

# in case import
open (my $notStaticFh, "grep -v ^static $inputFile | cut -d\"	\" -f1 | sort -u |") or die "can't open file:$inputFile\n$1";
createData($notStaticFh, "-");
close($notStaticFh);

# in case static import 
open (my $staticFh, "grep ^static $inputFile | cut -d\"	\" -f1 | sort -u |") or die "can't open file:$inputFile\n$1";
createData($staticFh, "o");
close($staticFh);

sub createData {
	my $fh = shift;
	my $static = shift;

	while(my $line = <$fh>) {
		chomp($line);
		my $libName = "unknown";
		my $baseVer = "";
		my $nextVer = "";

		# in case static import, remove "static "
		if ($static eq "o") {
			$line =~ s/^static[ ]*//;
		}

		# look for a match in the library before the migration
		foreach my $package (@basePackage) {
			if ($line =~ $package) {
				$libName = "JDKStandardLibrary";
				$baseVer = $inputBaseVer;
				last;
			}
		}

		# if not standard JDK library, find class name matches file name in input directory path.
		if ($libName eq "unknown") {
			if (($static eq "-" && $line !~ /.*\.\*$/) || $static eq "o") {
				my $checkFileName = getFileName($line, $static);
				if (grep /\/$checkFileName/, @files) {
					$libName = "userClass";
					$baseVer = "-";
					$nextVer = "-";
				}
			}
		}

		# look for a match in the library after the migration
		foreach my $package (@basePackage) {
			if ($line =~ $package) {
				$nextVer = $inputNextVer;
				last;
			}
		}

		printf("%s\t%s\t%s\t%s\t%s\n", $line, $static, $libName, $baseVer, $nextVer);
	}
}

# create filename from import class name or static import method
# ex)        abc.efg.hij -> hij.java
# ex) static abc.efg.hij.method -> hij.java
# ex) static abc.efg.hij.* -> hij.java
sub getFileName {
	my $packageName = shift;
	my $static = shift;
	my $retName;

	my $lastDotIndex = rindex($packageName, ".");
	if ($static eq "o") {
		my $nextDotIndex = rindex($packageName, ".", $lastDotIndex - 1);
		$retName = substr($packageName, $nextDotIndex + 1, $lastDotIndex - $nextDotIndex - 1);
	} else {
		$retName = substr($packageName, $lastDotIndex + 1);
	}

	return $retName . ".java";
}

# create src file list from direcotry stracture
# input parameter is file name Relative path
sub createSrcFileList {
	if (-f $_) {
		push(@files, $File::Find::name);
	}
}

# read std jdk package data
sub readPackageData {
	my $filename = shift;
	my @retArray = ();

	open(my $fh, "<", $filename) or die "Cannot open $filename for read: $!";
	while(my $line = <$fh>) {
		chomp ($line);
		if ($line =~ /^\#/) {
			next;
		}
		push(@retArray, $line);
	}
	close($fh);
	return @retArray;
}
