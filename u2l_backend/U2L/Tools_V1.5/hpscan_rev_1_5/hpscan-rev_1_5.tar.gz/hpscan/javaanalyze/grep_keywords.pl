#!/usr/bin/perl
# $Header: /data/cvsrepo/hpscan/javaanalyze/grep_keywords.pl,v 1.3 2015/12/02 10:10:00 kozeni Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P.
#
# script name : grep_keywords.pl
# description : extracts a portion that must be investigated from the specified file list
# execution   : grep_keywords.pl -b 1.4.1 -n 5 . JDK
# input	      : source_dir      : assessment target file directory
#             : diff target     : JDK|JSP|Servlet|OS
# option      : -b              : before migration version
#             : -n              : after  migration version
# output      : extracts result
#             : format per line : incompatible id<tab>file path<tab>line num<tab>context
#             : format per file : incompatible id<tab>file path<tab>

use File::Basename;
use Getopt::Long;

sub usage() {
	return "usage: " . basename($0) . " [-b base_version] [-n next_version] source_dir (JDK|JSP|Servlet|OS)\n" .
			"JDK JSP Servlet requires option -b, -n, OS don't need option.\n";
}

my $inputBaseVer;
my $inputNextVer;
GetOptions('base_version=s' => \$inputBaseVer, 'next_version=s' => \$inputNextVer) or die usage;

if (@ARGV != 2) {
	die usage;
}

my $sourceDir = $ARGV[0];
if (! -d $sourceDir) {
	die "source directory not found.($sourceDir)\n" . usage;
}
my $target = uc($ARGV[1]);

if ($target ne "JDK" && $target ne "OS" && $target ne "JSP" && $target ne "SERVLET") {
	die usage;
}

if ($target eq "JDK" || $target eq "JSP" || $target eq "SERVLET") { 
	if ($inputBaseVer eq "" ) {
		die "base_version is Required.\n" . usage;
	} elsif ($inputBaseVer !~ /[0-9.]+/) {
		die "base_version can use [0-9.]\n" . usage;
	}
	if ($inputNextVer eq "") {
		die "next_version is Required.\n" . usage;
	} elsif ($inputNextVer !~ /[0-9.]+/) {
		die "next_version can use [0-9.]\n" . usage;
	}
}

$dirname = dirname($0);
my $checklist = "$dirname/java_ic_check_list.txt";
my $data_dir = "$dirname/java_ic_data";
my %targetf;
my %grepptn;

# check list file
# format 
# <incompatible ID>:<search pattern>:<search target file list>
# ex)
# J2SE50-IC004:1:java_jsp_list
#

# read check list file
open(my $fh, "$checklist") || die "Can't open $checklist";
my $flag = 0;
my $inBaseVal=000;
my $inNextVal=000;
if ($target ne "OS") {
	$inBaseVal = getVersionValue($inputBaseVer);
	$inNextVal = getVersionValue($inputNextVer);
}
while(<$fh>) {
	chomp;
	next if (/^$/);	# Skip Empty lines
	next if (/^#/);	# Skip Comments
	
	# if version infomation
	if (/^\/\//) {
		my $tmp = $_;
		if (uc($tmp) =~ $target) {
			if ($target eq "OS") {
				$flag = 1;
			} else {
				$tmp =~ s/^\/\/ $target//;
				$tmp =~ s/ //g;
				(my $base, my $next) = split(/=>/, $tmp);
		
				if ($inBaseVal <= getVersionValue($base) && $inNextVal >= getVersionValue($next)) {
					$flag = 1;
				} else {
					$flag = 0;
				}
			}
		} else {
			$flag = 0;
		}
		next;
	}
	if ($flag) {
		(my $id, my $ptn, my $listf) = split(/:/, $_);
		$targetf{$id} = $listf;
		$grepptn{$id} = $ptn;
	}
}
close($fh);

# loop incompatible ID for each checklist
foreach my $id (sort keys(%targetf)) {
	my $keywordf = "$data_dir/$id.txt";
	my $ptn = $grepptn{$id};
	my $listf = $targetf{$id};
	my $cnt = 0;
	my @keys;   # array for search keywords
	my @files;  # array for search target file path

	if (! -r $listf) {
		print STDERR "$listf not found.\n";
		next;
	}

	# remove branch number
	my $bindex = index($id, "-", index($id, "-") + 1);
	if ($bindex != -1) {
		$id = substr($id, 0, $bindex);
	}

	# read array search keywords 
	open(my $fh, $keywordf) || die "Can't open $keywordf";
	while(<$fh>) {
		chomp;
		next if (/^[#]/);	# Skip Comments  
		$keys[$cnt++] = $_;
	}
	close($fh);

	# read array search target file path
	open(my $fh, $listf) || die "Can't open $listf";
	$cnt = 0;
	while(<$fh>) {
		chomp;
		$files[$cnt++] = $_;
	}
	close($fh);

	# loop file for each search target file
	for (my $i = 0; $i <= $#files; $i++) {
		my $fpath = $files[$i];
		my $is_match;
                my $countline=0;
		# search pattern 1
		if ($ptn eq 1) {
			open(my $fh, $sourceDir."/".$fpath) || die "Can't open ".$sourceDir."/".$fpath;
			while(<$fh>) {
				foreach my $key (@keys) {
					$countline++;
					if (/$key/) {
                                                    
						#$_ =~ s/\t/ /g;
						#print "printig the value in pattern1 : $countline \n";
						my $check=$. ;
						#print"print check in pattern1 :$check\n";
						#print "print partten1 $_ \n";
						#print "print partten1 $. \n";
						print "$id\t$fpath\t$.\t$_";
						last;
					}
				}
			}
			close($fh);

		# search pattern 2
		} elsif ($ptn eq 2) {
			 open(my $fh, $sourceDir."/".$fpath) || die "Can't open ".$sourceDir."/".$fpath;
                        while(<$fh>) {
                                foreach my $key (@keys) {
                                        $countline++;
                                        if (/$key/) {

                                                #$_ =~ s/\t/ /g;
                                                #print "printig the value in pattern1 : $countline \n";
                                                my $check=$. ;
                                                #print"print check in pattern1 :$check\n";
                                                #print "print partten1 $_ \n";
                                                #print "print partten1 $. \n";
                                                print "$id\t$fpath\t$.\t$_";
                                                last;
                                        }
                                }
                        }
                        close($fh);
}


		# search pattern 3
		  elsif ($ptn eq 3) {
			 open(my $fh, $sourceDir."/".$fpath) || die "Can't open ".$sourceDir."/".$fpath;
                        while(<$fh>) {
                                foreach my $key (@keys) {
                                        $countline++;
                                        if (/$key/) {

                                                #$_ =~ s/\t/ /g;
                                                #print "printig the value in pattern1 : $countline \n";
                                                my $check=$. ;
                                                #print"print check in pattern1 :$check\n";
                                                #print "print partten1 $_ \n";
                                                #print "print partten1 $. \n";
                                                print "$id\t$fpath\t$.\t$_";
                                                last;
                                        }
                                }
                        }
                        close($fh);
}
			#elsif ($ptn eq 3) {
#			foreach my $key (@keys) {
#				$is_match = 0;
#				open(my $fh, $sourceDir."/".$fpath) || die "Can't open ".$sourceDir."/".$fpath;
#				while(<$fh>) {
 #                                         $countline++;
#					if (/$key/) {
#						#$countline++;
#						$is_match = 1;
#						last;
#					}
#				}
#				close($fh);
#				if ($is_match) {
#					#$countline++;
#					next;
#				} else {
#
#					last;
#				}
#			}
#			if ($is_match) {
#				#$countline++;
#				$_ =~ s/\t/ /g;
#				print "printig the  value in pattern3 : $countline \n";
  #                              my $check=$. ;
 #                               print"print check in pattern3 :$check \n";
#
               	#		#print "$id\t$fpath\n";
		#		print "print partten3 $_\n";
		#		print "print partten3 $.\n";
		#		print "$id\t$fpath\t$.\t$_";
		#	}
		#}
	}

}

# create a comparable string from version
# ex) 1.4.2 -> 142
#     6     -> 600
sub getVersionValue {
	$input = shift;
	$input =~ s/\.//g;
	$input *= 10 while (length($input) < 3);
	return $input;
}
