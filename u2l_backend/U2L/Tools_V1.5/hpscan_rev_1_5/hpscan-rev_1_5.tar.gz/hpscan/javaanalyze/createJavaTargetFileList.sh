#!/bin/sh
# $Header: /data/cvsrepo/hpscan/javaanalyze/createJavaTargetFileList.sh,v 1.1 2014/05/14 05:43:32 morimoto Exp $
# (C) 2014 Hewlett-Packard Development Company, L.P. 
# create file liset for java assessment from source check results.
#
# usage        : createJavaTargetFileList.sh srccheck_log_dir
# parameter    : srccheck_log_dir : source check results file's directory
# output files : java_list.txt, jsp_list.txt, java_jsp_list.txt, java_jsp_sh_list.txt
#                c_h_list.txt, sh_list.txt


if [ $# -ne 1 ] ; then
	echo "usage : `basename $0` srccheck_log_dir" 1>&2
	exit 1;
fi

srcCheckDir=$1

# check srccheck log dir exists.
if [ ! -d $srcCheckDir ] ; then
	echo "$srcCheckDir is not directory." 1>&2
	exit 1
fi

# check java file lists exists.
if [ ! -r $srcCheckDir/java_files.out ] ; then
	echo "can't read file : $srcCheckDir/java_files.out" 1>&2
	exit 1
fi

grep "\.java$" $srcCheckDir/java_files.out > java_list.txt
grep -e "\.jsp$" -e "\.jspx$" $srcCheckDir/java_files.out > jsp_list.txt
cp $srcCheckDir/java_files.out java_jsp_list.txt
cp $srcCheckDir/java_files.out java_jsp_sh_list.txt

if [ -e c_h_list.txt ] ; then
	rm c_h_list.txt
fi
# exclude pro*c module
if [ -r $srcCheckDir/c_files.out ] ; then
	grep -e "\.c$" -e "\.h$" $srcCheckDir/c_files.out > c_h_list.txt
fi
# cxx_files.out contains only c++ module
if [ -r $srcCheckDir/cxx_files.out ] ; then
	cat $srcCheckDir/cxx_files.out >> c_h_list.txt
fi

if [ -e sh_list.txt ] ; then
	rm sh_list.txt
fi
if [ -r $srcCheckDir/?sh_list.out ] ; then
	cat $srcCheckDir/?sh_list.out > sh_list.txt
	cat sh_list.txt  >> java_jsp_sh_list.txt
fi

