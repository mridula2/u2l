Getting started
---------------

* Install [node.js](http://nodejs.org/download/)
* Install the node.js dependencies: `npm install`
* Run `node make` or `node make minify`

You can run `npm run lint` to run [JSHint](https://github.com/jshint/jshint)
and [csslint](https://github.com/stubbornella/csslint) for our files.
