#include <stdio.h>
int main()
{
    char str[5];
    snprintf(str, 10, "%s", "abc");
}
