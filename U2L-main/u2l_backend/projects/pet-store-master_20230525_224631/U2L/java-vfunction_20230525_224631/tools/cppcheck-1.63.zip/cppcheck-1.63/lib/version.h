#define CPPCHECK_VERSION_STRING "1.63"
#define CPPCHECK_VERSION 1,63,0,0
#define LEGALCOPYRIGHT L"Copyright (C) 2007-2013 Daniel Marjam\x00E4ki and Cppcheck team."
