<!-- BEGIN $Header: /repository/STK_CVS/STK/product/doc/htdocs-sol2linux/styles/Utils_rel.js,v 1.1 2005/03/02 22:34:00 rab Exp $ -->

	<!-- hide script from old browsers

	// changeImage (Image, SrcName)
	//
	// This function changes the src of the Image passed in to have the value
	// of SrcName. Used in conjunction with the OnMouseOver/OnMouseOut events
	// it implements a rollover effect.
	function changeImage (Image, SrcName) 
	{
   		if (document.images) 
    		document.images[Image].src = SrcName;
	}


	// end of script hiding -->

if ((is_nav4up || is_ie4up) || (!is_nav && !is_ie)) {
  ChooseStkStyleSheet();
}

// Function to choose the HPDR specific style sheet for use 
// based on the platform and browser version
// NOTE: This is dependent upon code in the snf2_utilities.js file.
function ChooseStkStyleSheet() {
	var fileHead = "styles/" + stylePrefix;
	var styles;

	if (is_win) {
		if (is_nav) {
			styles = fileHead + "styles_stk_win_ns.css";
		} else {
			// Windows Netscape fonts need to be larger than those for IE
			styles = fileHead + "styles_stk_win_ie.css";
		}
	} else if (is_mac) {
		if (is_ie5up) {
			// Default font settings for Mac IE5 match PC IE fonts
			styles = fileHead + "styles_stk_win_ie.css";
		} else {
			styles = fileHead + "styles_stk_mac.css";
		}
	} else if (is_unix) {
		styles = fileHead + "styles_stk_unix.css";
	} else {
		// Default style = macCSS
		// Macintosh stylesheets have the largest font sizes, which
		// will ensure readability
		styles = fileHead + "styles_stk_mac.css";
	}
	document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + styles + "\">");
	return true;
}
function updateForm() {
		var x=document.location.search;
		if(x.indexOf("?")==0) x=x.substring(1,x.length);
		
		var y=x.split("&");
	
		var key="";
		var data="";
		var source_val="";
		var dest_val="";
		var severity_val="";
		var impact_type_val="";
		var impact_class_val="";
		var format_val="";
		var title_val="";
		var sort_val="";
		
		for(i=0; i < y.length; i++) {
			key=y[i].split("=")[0];
			data=y[i].split("=")[1];
			
			switch(key){
				case "sourceos":	source_val = data;
									break;
				case "destos":		dest_val = data;
									break;
				case "severity":	severity_val = data;
									break;
				case "impact_type":	if(impact_type_val != "") impact_type_val=impact_type_val+","+data;
									else impact_type_val = data;
									break;
				case "impact_class":	if(impact_class_val != "") impact_class_val=impact_class_val+","+data;
									else impact_class_val = data;
									break;
				case "format":		format_val = data;
									break;									
				case "title":		title_val = data;
									break;									
				case "sort":		sort_val = data;
									break;																											
				default: 			; 
			}
		
		}
		
		document.webform.source.value=source_val;
		document.webform.destination.value=dest_val;
		document.webform.severity.value=severity_val;
		document.webform.format.value=format_val;
		document.webform.subtitle.value=title_val;
		document.webform.sort_type.value=sort_val;
		document.webform.impact_type.value=impact_type_val;
		document.webform.impact_class.value=impact_class_val;
}		
<!-- END Utils.js -->
