import React from 'react';

const WizardContext = React.createContext({});

export default WizardContext