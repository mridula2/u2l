//------------------------------------------------------------------
// This function will remove the leading and trailing blanks
// from the passed string
//------------------------------------------------------------------
 function Trim(myString, trimCharacter)
 {
      // Handle the error if trimCharacter is too long
      if (trimCharacter.length > 1)
      {
          alert("Trim error: '" + trimCharacter+ "' is more than one character long.");
          return myString;
      }
      // Make a copy of the string to work with
      newString = myString;
 
      // Remove the leading characters
      while (newString.charAt(0) == trimCharacter) 
      {
           newString = newString.substring(1,newString.length);
      }
 
      // Remove the trailing characters
      while (newString.charAt(newString.length - 1) ==  trimCharacter)
      {
         newString = newString.substring(0,newString.length - 1);
      }
 
      return newString;
 }

//--------------------------------------------------------------------------------------------------------
// This function will take input string and replaces every occurrence of fromString with toString
// with toString. 
//---------------------------------------------------------------------------------------------------------
  function replaceSubstring(inputString, fromString, toString) {
  // Goes through the inputString and replaces every occurrence of fromString with toString
  var temp = inputString;
  if (fromString == "") {
     return inputString;
  }
  if (toString.indexOf(fromString) == -1) { // If the string being replaced is not a part of the replacement string (normal situation)
     while (temp.indexOf(fromString) != -1) {
        var toTheLeft = temp.substring(0, temp.indexOf(fromString));
        var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
        temp = toTheLeft + toString + toTheRight;
     }
  } else { // String being replaced is part of replacement string (like "+" being replaced with "++") - prevent an infinite loop
     var midStrings = new Array("~", "`", "_", "^", "#");
     var midStringLen = 1;
     var midString = "";
     // Find a string that doesn't exist in the inputString to be used
     // as an "inbetween" string
     while (midString == "") {
        for (var i=0; i < midStrings.length; i++) {
           var tempMidString = "";
           for (var j=0; j < midStringLen; j++) { tempMidString += midStrings[i]; }
           if (fromString.indexOf(tempMidString) == -1) {
              midString = tempMidString;
              i = midStrings.length + 1;
           }
        }
     } // Keep on going until we build an "inbetween" string that doesn't exist
     // Now go through and do two replaces - first, replace the "fromString" with the "inbetween" string
     while (temp.indexOf(fromString) != -1) {
        var toTheLeft = temp.substring(0, temp.indexOf(fromString));
        var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
        temp = toTheLeft + midString + toTheRight;
     }
     // Next, replace the "inbetween" string with the "toString"
     while (temp.indexOf(midString) != -1) {
        var toTheLeft = temp.substring(0, temp.indexOf(midString));
        var toTheRight = temp.substring(temp.indexOf(midString)+midString.length, temp.length);
        temp = toTheLeft + toString + toTheRight;
     }
  } // Ends the check to see if the string being replaced is part of the replacement string or not
                        return temp; // Send the updated string back to the user
                     } // Ends the "replaceSubstring" function
                                         
//---------------------------------------------------------------------------------------------
// This function will call the correct search routine
//---------------------------------------------------------------------------------------------
function performSearch()
{
        var search_form = document.searchForm;
        // var keyword = search_form.keyword.value;
        var keyword = search_form.qt.value;
        
        var URL    = unescape(location.href);
        var xstart = URL.lastIndexOf("/") + 1;
	var xend   = URL.length;
	var hereName = URL.substring(xstart,xend);
	var herePath = URL.substring(0,xstart);

        if (Trim(keyword, " ") == "")
        {
           alert("Please enter a keyword to search for..");
           return false;
        }
        
        keyword = replaceSubstring(keyword," ", "+");

        for (var j = 0; j <search_form.elements.length; j++)
        {
           if (search_form.elements[j].type=="radio" && search_form.elements[j].checked) 
           {
             if (search_form.elements[j].value == "1")  
             {
                if (herePath.indexOf("/STK/") != -1) 
                {
	 	  document.stkSearch.search.value=keyword;
		  document.stkSearch.submit();
                }
                else if (herePath.indexOf("/STKL/") != -1)
                {
                  document.stkSearch.search.value=keyword;
                  document.stkSearch.submit();
                }
                else if (herePath.indexOf("/STKT/") != -1)
                {
                  document.stkSearch.search.value=keyword;
                  document.stkSearch.submit();
                }
                else if (herePath.indexOf("/STKS/") != -1)
                {
                  document.stkSearch.search.value=keyword;
                  document.stkSearch.submit();
                }
                else if (herePath.indexOf("/STKSL/") != -1)
                {
                  document.stkSearch.search.value=keyword;
                  document.stkSearch.submit();
                }
                else // Japanese search case
                {
                  document.stkSearch.search.value=keyword;
                  document.stkSearch.submit();
                }
             }
             else 
             {
		document.hpSearch.qt.value=keyword;
		document.hpSearch.submit();
             }
	   }
        }//endfor
	return false;
}

