<!-- BEGIN $Header: /repository/STK_CVS/STK/product/doc/htdocs-sol2linux/styles/Utils.js,v 1.2 2005/03/10 02:57:51 rab Exp $ -->

	<!-- hide script from old browsers

	// changeImage (Image, SrcName)
	//
	// This function changes the src of the Image passed in to have the value
	// of SrcName. Used in conjunction with the OnMouseOver/OnMouseOut events
	// it implements a rollover effect.
	function changeImage (Image, SrcName) 
	{
   		if (document.images) 
    		document.images[Image].src = SrcName;
	}


	// end of script hiding -->

if ((is_nav4up || is_ie4up) || (!is_nav && !is_ie)) {
  ChooseStkStyleSheet();
}

// Function to choose the HPDR specific style sheet for use 
// based on the platform and browser version
// NOTE: This is dependent upon code in the snf2_utilities.js file.
function ChooseStkStyleSheet() {
	var fileHead = "/STKSL/styles/" + stylePrefix;
	var styles;

	if (is_win) {
		if (is_nav) {
			styles = fileHead + "styles_stk_win_ns.css";
		} else {
			// Windows Netscape fonts need to be larger than those for IE
			styles = fileHead + "styles_stk_win_ie.css";
		}
	} else if (is_mac) {
		if (is_ie5up) {
			// Default font settings for Mac IE5 match PC IE fonts
			styles = fileHead + "styles_stk_win_ie.css";
		} else {
			styles = fileHead + "styles_stk_mac.css";
		}
	} else if (is_unix) {
		styles = fileHead + "styles_stk_unix.css";
	} else {
		// Default style = macCSS
		// Macintosh stylesheets have the largest font sizes, which
		// will ensure readability
		styles = fileHead + "styles_stk_mac.css";
	}
	document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + styles + "\">");
	return true;
}


<!-- END Utils.js -->
